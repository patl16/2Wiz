package com.company;

import java.awt.*;

public class Tile {
    public String filename;
    public boolean obstacle;
    public Image img;


}
