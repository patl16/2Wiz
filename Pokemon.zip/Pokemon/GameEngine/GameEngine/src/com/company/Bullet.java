package com.company;

public class Bullet
{
    public int X;
    public int Y;
    public int direction;
}
